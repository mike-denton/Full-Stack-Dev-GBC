
const transactionModel = require('../models/transactionModel')


const sendTransaction = (source, destination, value) => {

    // Step 3: 
    // i. require web3 and configure to run on hardhat port 8545
    // ii. use web3 api to send transaction to the hardhat ethereum blockchain
    // iii. return the receipt object result from hardhat
    console.log(`sendTransaction method called..`)
}

module.exports = {
    sendTransaction
}