const { transaction } = require('./modules');

const result = transaction.sendTransaction(
    '0xa0Ee7A142d267C1f36714E4a8F75612F20a79720', 
    '0x71bE63f3384f5fb98995898A86B02Fb2426c5788', 
    3000)