
import Transfer from './components/transfer';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";


function App() {
  return (
    <BrowserRouter>
    <Routes>
        <Route path="/" element={<Transfer />} />
    </Routes>
  </BrowserRouter>
  );
}

export default App;
