const fs = require('fs');
const zlib = require('zlib');
const readableStream = fs.createReadStream('output.txt');
const zLib = zlib.createGzip();
const writable = fs.createWriteStream('output.txt.gz');
readableStream.pipe(zLib).pipe(writable);