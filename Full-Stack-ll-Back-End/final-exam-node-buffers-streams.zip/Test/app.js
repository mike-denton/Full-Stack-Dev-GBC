const fs = require('fs');


const readableStream = fs.createReadStream('data.txt');
const writable = fs.createWriteStream('output.txt');
readableStream.on('data',(chunk)=>{
    
    const buffer = Buffer.from(chunk,'utf8')
        console.log(`converting to bytes\n\n`)
        console.log(buffer);

        console.log(`converting to string\n\n`)

        console.log(buffer.toString());
    })
    readableStream.pipe(writable);
    
    readableStream.on('end',()=>{
        writable.end();
        console.log("writing is completed!")
    })