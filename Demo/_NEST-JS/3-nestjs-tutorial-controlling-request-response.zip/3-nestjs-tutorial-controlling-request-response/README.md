
`nest generate module customers`

`nest g controller customer/controllers/customers`

`nest g service customers/services/customers`

`npm run start` 
`npm run start:dev`

`http://localhost:4000/customers/1`  # 202-OK
`http://localhost:4000/customers/12` # 404-Customer not found

`http://localhost:4000/customers/search/3`