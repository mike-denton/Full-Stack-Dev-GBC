import { Injectable } from '@nestjs/common';

@Injectable()
export class CustomersService {

    private users = [
        {
            id: 1,
            email: 'admin@test.com',
            created: new Date()
        },
        {
            id: 2,
            email: 'guest@test.com',
            created: new Date()
        }
    ]
    findCustomerById(id: number) {
        return this.users.find((user) => user.id == id)
    }
}
