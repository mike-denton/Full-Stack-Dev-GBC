
`nest generate module customers`

`nest g controller customer/controllers/customers`

`nest g service customers/services/customers`

//npm run start: "nest start",
//npm run start:dev": "nest start --watch",