import { Controller, Get, Post, Req, Res, Param, Body } from '@nestjs/common';
import { HttpStatus } from '@nestjs/common/enums';
import { HttpException } from '@nestjs/common/exceptions';
import { ParseIntPipe } from '@nestjs/common/pipes';
import { Request, Response } from 'express'
import { CreateCustomerDto } from 'src/customers/dtos/CreateCustomer.dto';
import { CustomersService } from 'src/customers/services/customers/customers.service';

@Controller('customers')
export class CustomersController {

    constructor(private customerService: CustomersService) {

    }

    // ### Express traditional request/response handling

    // route params, similar to express
    // annotate the requesst and response, which are provided by Express interface
    @Get(':id')
    getCustomer(
        @Param('id') id: number, 
        @Req() req: Request, 
        @Res() res: Response) {
        // req.body, req.header, req.body, req.params, req.send(200), req.send(403)
        console.log(`customer controller - get param - id: ${id}`)
     
        const customer = this.customerService.findCustomerById(id)
        if (customer) {
            res.send(customer) // 200-OK
        }
        else {
            res.status(400).send({ msg: 'Customer not found'})
        }

    }

    // NEST.js way of handling Request/Response
    /// @Request and @Response, not needed. If included you must us them, however Nest will
    // handle internall if not in controller action

    @Get('/search/:id')
    searchCustomerById(@Param('id', ParseIntPipe) id:number) {
        const customer = this.customerService.findCustomerById(id)
        if (customer) return customer;
        else throw new HttpException('Customer not found in search', HttpStatus.BAD_REQUEST)
    }

    @Get('/')
    getAllCustomers() {
        return this.customerService.getCustomers()

    }
    // getting the request body using express can be used req.body in legacy
    // DTO - data transfer network, data contract/interface for data sent over network
    // Nest.js recommends to use ES6 classes, in place of interface
    @Post('create')
    createCustomer(@Body() createCustomerDto: CreateCustomerDto) {
        console.log(createCustomerDto)
        if(createCustomerDto)
        this.customerService.createCustomer(createCustomerDto)
    }

}
