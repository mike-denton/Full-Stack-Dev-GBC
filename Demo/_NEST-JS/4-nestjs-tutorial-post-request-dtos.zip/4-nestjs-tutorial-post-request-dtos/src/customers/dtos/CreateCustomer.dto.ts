export class CreateCustomerDto {
    email: string;
    id: number;
    name: string;
}