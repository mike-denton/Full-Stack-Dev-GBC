import { Injectable } from '@nestjs/common';
import { CreateCustomerDto } from 'src/customers/dtos/CreateCustomer.dto';
import { Customer } from 'src/customers/types/Customers';
@Injectable()
export class CustomersService {

    private customers: Customer[] = [
        {
            id: 1,
            email: 'admin@test.com',
            name: 'Admin Test'
        },
        {
            id: 2,
            email: 'guest@test.com',
            name: 'Guest Account'
        }
    ]
    findCustomerById(id: number) {
        return this.customers.find((user) => user.id == id)
    }

    createCustomer(customerDto: CreateCustomerDto) {
        this.customers.push(customerDto)
    }

    getCustomers() {
        return this.customers;
    }
}
