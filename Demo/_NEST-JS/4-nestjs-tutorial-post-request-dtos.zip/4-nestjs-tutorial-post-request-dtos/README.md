
`npm run start` 
`npm run start:dev`


`http://localhost:4000/api/customers/search/1`

#1. bootstrap the global prefix for all routes with 'api' in main.ts

#2 use postman and post request on `http://localhost:4000/api/customers/create`
# using a raw payload with the following, JSON type in POSTMAN!!!!

`
{
    "email": "tester@gmail.com",
    "id": 4,
    "name": "Tester Account"
}

`