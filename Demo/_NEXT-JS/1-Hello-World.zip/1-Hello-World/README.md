
# create next-js applicatino
`npx create-next-app`

# run the next.js application
`yarn dev`

# go to api/index.js and update the header with `hello world`