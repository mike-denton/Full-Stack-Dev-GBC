const Details = () => {
    return (
        <div>
            <h1>Members Index</h1>
            <p>Next.js automatically creates a root path for any index.js file found..</p>
        </div>
    )
}

export default Details;