const Details = () => {
    return (
        <div>
            <h1>Member Details</h1>
            <p>Next.js automatically creates the subroute /members/details</p>
        </div>
    )
}

export default Details;