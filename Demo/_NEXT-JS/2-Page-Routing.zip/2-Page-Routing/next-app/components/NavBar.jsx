import Link from 'next/link'

// Note: each page has it's on javascript bundle and it gets served when we
// navigate to that page for the first time <open network tab to view>...
// next.js prefetches link bundles..

const NavBar = () => {
    return (
        <>
            <div class="logo">
                <h1>Navigation</h1>
            </div>
           <Link href="/">Home </Link>
           <Link href="/about">About </Link> 
           <Link href="/members">Members </Link> 
        </>
    ) 
}

export default NavBar;