const Footer = () => {
    return (
        <>
           <div>
                Copyright 2023 - GBC
           </div>
        </>
    ) 
}

export default Footer;