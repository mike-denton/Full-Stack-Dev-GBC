Alexei Pancratov - 101333496

How to run:
- Run npm install
- Run npm start