import React from 'react';

const LogItem = ({ diffMinutes, diffSeconds}) => {
  return (
    <p className="container-item">{`Duration => minutes ${diffMinutes} seconds: ${diffSeconds}`}</p>
  );
}

export default LogItem;