import React, { useState } from "react";
import Clock from "./Clock";
import LogItem from "./LogItem";

const { v4: uuidv4 } = require("uuid");

const Timer = () => {
  const [timerState, setTimerState] = useState({
    startTime: null,
    endTime: null,
  });
  const [timerLog, setTimerLog] = useState([]);
  const [shouldDisplayClock, setShouldDisplayClock] = useState(false);

  const onStartTimerClick = () => {
    setTimerState({
      startTime: new Date(),
    });
    setShouldDisplayClock(true);
  };

  const onStopTimerClick = () => {
    setShouldDisplayClock(false);

    const endTime = new Date();

    setTimerState({
      startTime: timerState.startTime,
      endTime: endTime,
    });

    const diffMinutes = Math.floor((endTime - timerState.startTime) / (1000 * 60));
    const diffSeconds = Math.floor((endTime - timerState.startTime) / 1000) % 60;

    setTimerLog([
      ...timerLog,
      {
        diffMinutes: diffMinutes,
        diffSeconds: diffSeconds,
      }
    ]);
  };

  const onResetTimerClick = () => {
    setTimerState({
      startTime: null,
      endTime: null,
    });
    setTimerLog([]);
    setShouldDisplayClock(false);
  };

  return (
    <>
      <div className="container">
        <table id="timerTable">
          <tbody>
            <tr>
              <td>
                <span>Start Time:</span>
              </td>
            </tr>
            <tr>
              <td>
                <input
                  id="txtStartTime"
                  type="text"
                  readOnly={true}
                  value={
                    timerState.startTime
                      ? timerState.startTime.toLocaleTimeString()
                      : ""
                  }
                />
              </td>
            </tr>
            <tr>
              <td>
                <span>End Time:</span>
              </td>
            </tr>
            <tr>
              <td>
                <input
                  id="txtEndTime"
                  type="text"
                  readOnly={true}
                  value={
                    timerState.endTime
                      ? timerState.endTime.toLocaleTimeString()
                      : ""
                  }
                />
              </td>
            </tr>
            {shouldDisplayClock && (
              <tr>
                <td>
                  <Clock />
                </td>
              </tr>
            )}
            <tr>
              <td>
                <button id="btnStart" type="button" onClick={onStartTimerClick}>
                  Start
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <button id="btnStop" type="button" onClick={onStopTimerClick}>
                  Stop
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <button id="btnReset" type="button" onClick={onResetTimerClick}>
                  Reset
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div id="timer">
        {timerLog.map(tl => (
          <LogItem
            key={uuidv4()}
            diffMinutes={tl.diffMinutes}
            diffSeconds={tl.diffSeconds}
          />
        ))}
      </div>
    </>
  );
};

export default Timer;
