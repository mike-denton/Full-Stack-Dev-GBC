import React, { useState } from "react";

function Todo({ todo, index }) {
  return <div className="todo">{todo.text}</div>;
}
function App() {
  // equivalent to this.state and this.setState in class component
  const [todos, setTodos] = useState([
    {
      text: "Learn about React",
      isCompleted: false
    },
    {
      text: "Finish Assingment Part 2",
      isCompleted: false
    },
    {
      text: "Plan for Vacation!",
      isCompleted: false
    }
  ]);

  return (
    <div className="app">
      <div className="todo-list">
        {todos.map((item, index) => (
          <Todo key={index} index={index} todo={item} />
        ))}
      </div>
    </div>
  );
}
export default App;
