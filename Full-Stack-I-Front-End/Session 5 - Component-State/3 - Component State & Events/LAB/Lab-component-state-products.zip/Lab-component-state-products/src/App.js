import React from 'react';
import Product from './components/Product/Product';

function App() {
  return <Product />
}

export default App;