import React, { useEffect, useState } from "react"
import { useParams } from "react-router-dom";
import axios from 'axios'


function Wallet(props) {

   let params = useParams();
   const [wallet, setWallet] = useState(null)

   useEffect(() => {
      const address = params.address || ''
       axios.get(`http://localhost:3001/account/balance?account=${address}`)
          .then(res => {
           setWallet(res.data);
              console.log(res.data)
          })
   },[])

   const buildWalletDetails = () => {
      if(wallet) {
         console.log(`buildWalletDetails: ${JSON.stringify(wallet)}`)
         return (
            <div class="container">
               <p><b>Address:</b> {wallet.account}</p>
               <p><b>Balance:</b> {wallet.balance} ETH</p>
            </div>
         )
      }
   }
    return(
       <>
          <h1>My Wallet</h1>
          { buildWalletDetails() }
       </>
    )

}

export default Wallet;