import { Link } from "react-router-dom";

function Navigation () {
  return (
    <>
      <nav>
        <Link to="/">Transactions</Link> |{" "}
        <Link to="addresses">Addresses</Link> |{" "}
        <Link to="wallet">Wallet</Link> |{" "}
      </nav>
    </>
  );
}

export default Navigation