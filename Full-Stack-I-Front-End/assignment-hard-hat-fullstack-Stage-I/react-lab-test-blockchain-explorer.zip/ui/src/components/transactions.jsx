
import React, { useEffect, useState } from "react"
import axios from 'axios'
function Transactions () {

    const [transactions, setTransactions] = useState([])

 useEffect(() => {
     axios.get("http://localhost:3001/transaction/history")
        .then(data => {
         setTransactions(data);
            console.log(data)
        })
 },[])

//  {"_id":"62428623209adfad7175feb2","source":"0xdd2fd4581271e230360230f9337d5c0430bf44c0","destination":"0x8626f6940e2eb28930efb4cef49b2d1f2c9c1199","amount":"250","status":"SUCCESS","gasUsed":"21000","receiptHash":"0x39ae9270a0f2edac19f51d1e9b42380d73440f142d1d1709fb3806c97539c6eb","createdAt":"2022-03-29T04:08:03.172Z","updatedAt":"2022-03-29T04:08:03.172Z","__v":0}



 const buildListItems = () => {
    debugger
    if(transactions && transactions.data) {
      return  ( 
      <ul>
         {
         transactions.data.map((txn) => (
            <li key={txn.id} className="container">
                <p><b>Transaction Hash:</b> {txn.receiptHash}</p>
                <p><b>Status:</b> { txn.status }</p>
                <p><b>Timestamp:</b> { txn.createdAt } </p>
                <p><b>From:</b> { txn.source } </p>
                <p><b>To:</b> { txn.destination }</p>
                <p><b>Value:</b> { txn.amount } <b>ETH</b> </p>
                <p><b>Gas Used:</b> { txn.gasUsed } </p>
            {/* {JSON.stringify(txn)} */}
            
            </li>
         ))
         }
      </ul>)
    }
 }
    return(
      
       <>
          <h1>Transaction History</h1>
          { buildListItems() }
       </>
    )
}

export default Transactions;