

import React, { useEffect, useState } from "react"
import axios from 'axios'
import { Link } from "react-router-dom";

function Accounts() {

 const [addresses, setAddresses] = useState([])

 useEffect(() => {
    //  fetch("http://localhost:8083/account/addresses")
    //     .then(res => {
    //         console.log(res)
    //     })
     axios.get("http://localhost:3001/account/addresses")
        .then(data => {
         setAddresses(data);
            console.log(data)
        })
 },[])

 const handleClick = () => {
    alert('redirect')
 }
 const buildListItems = () => {
    debugger
    if(addresses && addresses.data) {
      return  ( 
      <ul>
         {addresses.data.map((address) => (
            <li key={address.id}>
               <Link to={`wallet/${address}`}>{ address }</Link>
            </li>
         ))}
      </ul>)
    }
 }
    return(
      
       <>
          <h1>Blockchain Node Addresses</h1>
          { buildListItems() }
       </>
    )

}

export default Accounts;
