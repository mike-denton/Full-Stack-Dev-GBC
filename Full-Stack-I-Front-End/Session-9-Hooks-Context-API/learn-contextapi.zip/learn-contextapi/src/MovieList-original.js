import React, { useState } from "react";
import Movie from "./Movie";

const MovieList = () => {
  const [movies, setMovies] = useState([
    {
      name: "Game of Thrones",
      price: "$10",
      id: 23124
    },
    {
      name: "Inception",
      price: "$10",
      id: 23125
    },
    {
      name: "The Matrix",
      price: "$20",
      id: 23130
    }
  ]);
  return (
    <div>
      {movies.map(movie => (
        <li>
          <Movie name={movie.name} price={movie.price} key={movie.id} />
        </li>
      ))}
    </div>
  );
};
export default MovieList;
