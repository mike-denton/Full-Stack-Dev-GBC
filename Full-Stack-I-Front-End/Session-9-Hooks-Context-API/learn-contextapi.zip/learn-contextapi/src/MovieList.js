import React, { useState, useContext } from "react";
import Movie from "./Movie";
import { MovieContext } from "./MovieContext";

const MovieList = () => {

  const [movies] = useContext(MovieContext); //React Hook!
  
  return (
    <div>
      {movies.map(movie => (
        <li>
          <Movie name={movie.name} price={movie.price} key={movie.id} />
        </li>
      ))}
    </div>
  );
};
export default MovieList;
