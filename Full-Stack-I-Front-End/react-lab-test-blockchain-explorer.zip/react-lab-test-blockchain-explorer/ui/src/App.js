

import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Transfer from './components/transfer';

function App() {
  return (
    <Transfer />
  );
}

export default App;
