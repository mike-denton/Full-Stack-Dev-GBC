var ft = require('./sportsteam');

// set module property
ft.teamname = 'Leafs';

// call module method
ft.Cheer();