
// export named function 
exports.Cheer = function () {
    console.log('Go! ' + this.teamname + ' Go!');
}