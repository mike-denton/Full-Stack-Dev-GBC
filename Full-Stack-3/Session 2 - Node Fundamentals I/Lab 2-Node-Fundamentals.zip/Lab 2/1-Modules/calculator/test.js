module.exports = {
    fn: function () { }
}