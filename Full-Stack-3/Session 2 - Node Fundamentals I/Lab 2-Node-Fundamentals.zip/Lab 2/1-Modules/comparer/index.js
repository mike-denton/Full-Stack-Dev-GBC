
// export named function
exports.AreNumbersEqual = function () {
    console.log('comparing two numbers: ' +  this.x + ',' + this.y);
    return this.x == this.y;
}